import java.io.*;
import java.util.Scanner;

public class FileEncryptDecrypt {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Display menu for the user
        System.out.println("Welcome to File Encryptor/Decryptor!");
        System.out.println("Choose an option:");
        System.out.println("1. Encrypt a file");
        System.out.println("2. Decrypt a file");
        System.out.print("Enter your choice (1 or 2): ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        try {
            // Get file names from the user
            System.out.print("Enter the input file name: ");
            String inputFileName = scanner.nextLine();
            System.out.print("Enter the output file name: ");
            String outputFileName = scanner.nextLine();

            // Perform the chosen operation
            if (choice == 1) {
                encryptFile(inputFileName, outputFileName);
                System.out.println("File encrypted successfully!");
            } else if (choice == 2) {
                decryptFile(inputFileName, outputFileName);
                System.out.println("File decrypted successfully!");
            } else {
                System.out.println("Invalid choice. Please restart the program and try again.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }

    // Method to encrypt the file
    public static void encryptFile(String inputFileName, String outputFileName) throws IOException {
        FileInputStream inputFile = new FileInputStream(inputFileName);
        FileOutputStream outputFile = new FileOutputStream(outputFileName);

        int byteData;
        while ((byteData = inputFile.read()) != -1) {
            outputFile.write(byteData + 5); // Encrypt by adding 5
        }

        inputFile.close();
        outputFile.close();
    }

    // Method to decrypt the file
    public static void decryptFile(String inputFileName, String outputFileName) throws IOException {
        FileInputStream inputFile = new FileInputStream(inputFileName);
        FileOutputStream outputFile = new FileOutputStream(outputFileName);

        int byteData;
        while ((byteData = inputFile.read()) != -1) {
            outputFile.write(byteData - 5); // Decrypt by subtracting 5
        }

        inputFile.close();
        outputFile.close();
    }
}
