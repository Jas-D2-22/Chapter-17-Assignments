import java.io.*;
import java.util.Random;

public class Exercise17_03 {

    public static void main(String[] args) {
        try {
            // Step 1: Create and write to the file
            createFileWithRandomIntegers("Exercise17_03.dat");

            // Step 2: Read and calculate the sum of integers
            int sum = readFileAndCalculateSum("Exercise17_03.dat");
            System.out.println("The sum of the integers in the file is: " + sum);
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Method 1: Create a file and write 100 random integers
    public static void createFileWithRandomIntegers(String fileName) throws IOException {
        Random random = new Random();
        try (DataOutputStream outputStream = new DataOutputStream(new FileOutputStream(fileName, true))) {
            for (int i = 0; i < 100; i++) {
                int randomInt = random.nextInt(100); // Generate random integers (0 to 99)
                outputStream.writeInt(randomInt);
            }
        }
        System.out.println("Random integers written to file: " + fileName);
    }

    // Method 2: Read the integers from the file and find their sum
    public static int readFileAndCalculateSum(String fileName) throws IOException {
        int sum = 0;
        try (DataInputStream inputStream = new DataInputStream(new FileInputStream(fileName))) {
            while (inputStream.available() > 0) {
                sum += inputStream.readInt();
            }
        }
        return sum;
    }
}

